(function($){
	var h1 = $('h1'),
	 h2 = $('h2'),
	 tl = new TimelineLite({paused:true}),
	 dot = $('.dot'),
	 loader = $('#loader'),
	 tlLoader = new TimelineMax({repeat:2, onComplete: loadContent});

	// TweenLite.from(h1, 2, {y:200, autoAlpha:0, ease: Back.easeOut.config(1.7)});
	// TweenLite.from(h2, 2, {y:200, autoAlpha:0, ease: Back.easeOut.config(1.7)});

	tl
		.from(h2, 1, {y:200, autoAlpha:0, ease: Back.easeOut.config(1.7)})
		.from(h1, 1, {y:200, autoAlpha:0, ease: Back.easeOut.config(1.7)}, '-=0.8');

	tlLoader
		.staggerFromTo(dot, 0.3, {y:0, autoAlpha:0}, {y:20, autoAlpha:1, ease:Back.easeInOut}, 0.05)
		.fromTo(loader, 0.3, {autoAlpha:1, scale:1.3}, {autoAlpha:0, scale:1, ease:Power0.easeNone}, 0.9);

		function loadContent(){
			var tlLoaderOut = new TimelineLite({onComplete: contentIn});
			tlLoaderOut
			.set(dot, {backgroundColor:'#fff'})
			.to(loader, 0.3, {autoAlpha: 1, scale:1.3, ease: Power0.easeNone})
			.staggerFromTo(dot, 0.3, {y:0, autoAlpha:0}, {y:20, autoAlpha:1, ease:Back.easeInOut}, 0.05, 0)
			.to(loader, 0.3, {y:-150, autoAlpha:0, ease: Back.easeIn}, '+=0.3');
		}

		function contentIn(){
			tl.play();
		}

})(jQuery);