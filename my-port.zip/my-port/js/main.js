


$(document).ready(function() {
  $(".title").lettering();
});

$(document).ready(function() {
  animation();
}, 1000);


function animation() {
  var title1 = new TimelineMax();

  title1
  .staggerFrom(".title span", 1.8, { ease: Elastic.easeOut.config(1, .5), opacity: 0, y: 80 }, 0.01 );
}
